from microbit import sleep, running_time
from maqueen import *

def drive_margin_area():
    if read_line_sensor_state(MyEnumLineSensor.SENSOR_M):
        control_motor(MyEnumMotor.ALL_MOTOR, MyEnumDir.FORWARD, 38)
    else:
        l = read_line_sensor_state(MyEnumLineSensor.SENSOR_L1)
        r = read_line_sensor_state(MyEnumLineSensor.SENSOR_R1)
        if l == 0 and r == 1:
            control_motor(MyEnumMotor.LEFT_MOTOR,  MyEnumDir.FORWARD, 30)
            control_motor(MyEnumMotor.RIGHT_MOTOR, MyEnumDir.FORWARD, 6)
        elif l == 1 and r == 0:
            control_motor(MyEnumMotor.RIGHT_MOTOR, MyEnumDir.FORWARD, 30)
            control_motor(MyEnumMotor.LEFT_MOTOR,  MyEnumDir.FORWARD, 6)
        elif l == 0 and r == 0:
            control_motor_stop(MyEnumMotor.ALL_MOTOR)

def drive_until_margin():
    l = read_line_sensor_state(MyEnumLineSensor.SENSOR_L1)
    r = read_line_sensor_state(MyEnumLineSensor.SENSOR_R1)
    if l == 0 and r == 1:
        control_motor(MyEnumMotor.LEFT_MOTOR,  MyEnumDir.FORWARD, 30)
        control_motor(MyEnumMotor.RIGHT_MOTOR, MyEnumDir.FORWARD, 6)
    elif l == 1 and r == 0:
        control_motor(MyEnumMotor.RIGHT_MOTOR, MyEnumDir.FORWARD, 30)
        control_motor(MyEnumMotor.LEFT_MOTOR,  MyEnumDir.FORWARD, 6)
    else:
        control_motor(MyEnumMotor.ALL_MOTOR, MyEnumDir.FORWARD, 38)


def turn_left():
    l = read_line_sensor_state(MyEnumLineSensor.SENSOR_L1)
    if l == 1:
        control_motor_stop(MyEnumMotor.ALL_MOTOR)
    else:
        control_motor(MyEnumMotor.LEFT_MOTOR,  MyEnumDir.BACKWARD, 38)
        control_motor(MyEnumMotor.RIGHT_MOTOR, MyEnumDir.FORWARD, 38)

def turn_right():
    r = read_line_sensor_state(MyEnumLineSensor.SENSOR_R1)
    if r == 1:
        control_motor_stop(MyEnumMotor.ALL_MOTOR)
    else:
        control_motor(MyEnumMotor.LEFT_MOTOR,  MyEnumDir.FORWARD, 38)
        control_motor(MyEnumMotor.RIGHT_MOTOR, MyEnumDir.BACKWARD, 38)




def turnLeft(degrees):
    sleep(1000)
    duration = degrees/360*1550+80
    start_time = running_time()

    while running_time() - start_time < duration * 1.2:
        if running_time() - start_time < duration * 0.8:
            control_motor(MyEnumMotor.LEFT_MOTOR,  MyEnumDir.BACKWARD, 38)
            control_motor(MyEnumMotor.RIGHT_MOTOR, MyEnumDir.FORWARD, 38)
        else:
            turn_left()
        sleep(10)
    stop()


def turnRight(degrees):
    sleep(1000)
    duration = degrees/360*1570+100
    start_time = running_time()

    while running_time() - start_time < duration * 1.2:
        if running_time() - start_time < duration * 0.8:
            control_motor(MyEnumMotor.LEFT_MOTOR,  MyEnumDir.FORWARD, 38)
            control_motor(MyEnumMotor.RIGHT_MOTOR, MyEnumDir.BACKWARD, 38)
        else:
            turn_right()
        sleep(10)
    stop()

def forward(distance):
    sleep(1000)
    # Noch nicht 100% exakt (verbessern wenn zeit übrig)
    duration = distance/20*740+100
    start_time = running_time()

    while running_time() - start_time < duration * 1.8:
        if running_time() - start_time < duration * 0.8:
            drive_until_margin()
        else:
            drive_margin_area()
        sleep(10)
    
    stop()

def stop():
    control_motor_stop(MyEnumMotor.ALL_MOTOR)
