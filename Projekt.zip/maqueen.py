from microbit import i2c, display, Image, sleep

# I²C address and registers
_I2C_ADDR            = 0x10
_LEFT_MOTOR_REG      = 0x00
_RIGHT_MOTOR_REG     = 0x02
_LINE_STATE_REG      = 0x1D
_VERSION_CNT_REG     = 0x32
_VERSION_DATA_REG    = 0x33

class MyEnumMotor:
    LEFT_MOTOR = 0
    RIGHT_MOTOR = 1
    ALL_MOTOR = 2

class MyEnumDir:
    FORWARD = 0
    BACKWARD = 1

class MyEnumLineSensor:
    SENSOR_L2 = 0
    SENSOR_L1 = 1
    SENSOR_M  = 2
    SENSOR_R1 = 3
    SENSOR_R2 = 4

def i2c_init():
    """
    Initialize the Maqueen’s I²C interface, resetting it and waiting
    until the firmware version register becomes nonzero.
    """
    # system reset
    buf = bytearray([0x49, 1])
    i2c.write(_I2C_ADDR, buf)
    sleep(100)

    # poll version until nonzero
    while True:
        i2c.write(_I2C_ADDR, bytearray([_VERSION_CNT_REG]))
        v = i2c.read(_I2C_ADDR, 1)[0]
        if v != 0:
            break
        display.show(Image.SAD)
        sleep(200)
        display.clear()
    display.show(Image.HAPPY)
    sleep(200)
    display.clear()

def control_motor(emotor, edir, speed):
    """
    emotor: MyEnumMotor
    edir:   MyEnumDir
    speed:  0–255
    """
    if emotor == MyEnumMotor.LEFT_MOTOR:
        buf = bytearray([_LEFT_MOTOR_REG, edir, speed])
    elif emotor == MyEnumMotor.RIGHT_MOTOR:
        buf = bytearray([_RIGHT_MOTOR_REG, edir, speed])
    else:
        # both motors
        buf = bytearray([_LEFT_MOTOR_REG, edir, speed,
                         edir, speed])
    i2c.write(_I2C_ADDR, buf)

def control_motor_stop(emotor):
    """
    Stop one or both motors.
    """
    if emotor == MyEnumMotor.LEFT_MOTOR:
        buf = bytearray([_LEFT_MOTOR_REG, 0, 0])
    elif emotor == MyEnumMotor.RIGHT_MOTOR:
        buf = bytearray([_RIGHT_MOTOR_REG, 0, 0])
    else:
        buf = bytearray([_LEFT_MOTOR_REG, 0, 0,
                         0, 0])  # two zeros for right
    i2c.write(_I2C_ADDR, buf)

def read_line_sensor_state(eline):
    """
    Read the digital (0/1) line sensor:
      SENSOR_L1, SENSOR_M, SENSOR_R1 etc.
    """
    i2c.write(_I2C_ADDR, bytearray([_LINE_STATE_REG]))
    data = i2c.read(_I2C_ADDR, 1)[0]

    if eline == MyEnumLineSensor.SENSOR_L1:
        return 1 if (data & 0x08) else 0
    if eline == MyEnumLineSensor.SENSOR_M:
        return 1 if (data & 0x04) else 0
    if eline == MyEnumLineSensor.SENSOR_R1:
        return 1 if (data & 0x02) else 0
    if eline == MyEnumLineSensor.SENSOR_L2:
        return 1 if (data & 0x10) else 0
    # SENSOR_R2 or fallback
    return 1 if (data & 0x01) else 0