from microbit import button_a
from m241code import forward, turnLeft, turnRight, stop
from maqueen import *

i2c_init()

while True:
    if button_a.is_pressed():
        # Hier kannst du deinen Code reinschreiben:
        for i in range (2):
            for i in range(5):
                forward(20)
                turnRight(144)
                forward(20)
                turnLeft(72)
        
        # Bis hierhin
