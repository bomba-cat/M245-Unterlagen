from microbit import button_a
from m241code import forward, turnLeft, turnRight, stop
from maqueen import *

i2c_init()

while True:
    if button_a.is_pressed():
        # Hier kannst du deinen Code reinschreiben:
        for i in range (3):
            forward(20)
            turnLeft(90)
            forward(10)
            turnRight(90)
            forward(10)
            turnRight(90)
            forward(28)
            turnRight(90)
            forward(10)
            turnRight(90)
            forward(10)
            turnLeft(90)
            forward(20)
            turnRight(90)
            forward(10)
            turnRight(90)
        
        # Bis hierhin
