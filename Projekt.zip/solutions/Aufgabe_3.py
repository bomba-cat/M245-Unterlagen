from microbit import button_a
from m241code import forward, turnLeft, turnRight, stop
from maqueen import *

i2c_init()

while True:
    if button_a.is_pressed():
        # Hier kannst du deinen Code reinschreiben:
        for i in range(4):
            forward(12)
            turnRight(90)
            forward(12)
            turnLeft(90)
            
        turnRight(180)
        forward(50)
        turnRight(90)
        forward(50)
        turnRight(90)
           
        # Bis hierhin
