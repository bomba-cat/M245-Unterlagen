from microbit import button_a
from m241code import forward, turnLeft, turnRight, stop
from maqueen import *

i2c_init()

while True:
    if button_a.is_pressed():
        # Hier kannst du deinen Code reinschreiben:
        
        def square(side):
            turnLeft(135)
            forward(side*0.65)
            turnRight(90)
            forward(side)
            turnRight(90)
            forward(side)
            turnRight(90)
            forward(side*0.65)
            turnLeft(135)
            
        forward(14)
        square(18)
        forward(14)
        turnRight(120)
        forward(14)
        square(18)
        forward(14)
        turnRight(120)
        forward(11)
        square(34)
        forward(11)
        turnRight(120)

        # Bis hierhin
