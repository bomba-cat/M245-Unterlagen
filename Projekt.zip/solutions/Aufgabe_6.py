from microbit import button_a
from m241code import forward, turnLeft, turnRight, stop
from maqueen import *

i2c_init()

while True:
    if button_a.is_pressed():
        # Hier kannst du deinen Code reinschreiben:
        x = 40 #Zuerst hier 20
        y = 20 #Zuerst hier 10
        z = 54 #Zuerst hier 27
        
        for i in range (3):
            forward(x)
            turnLeft(90)
            forward(y)
            turnRight(90)
            forward(y)
            turnRight(90)
            forward(z)
            turnRight(90)
            forward(y)
            turnRight(90)
            forward(y)
            turnLeft(90)
            forward(x)
            turnRight(90)
            forward(y)
            turnRight(90)
        
        # Bis hierhin
