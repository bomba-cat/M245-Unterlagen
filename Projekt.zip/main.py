from microbit import button_a
from m241code import forward, turnLeft, turnRight, stop
from maqueen import *

i2c_init()

while True:
    if button_a.is_pressed():
        # Hier kannst du deinen Code reinschreiben:

        

        # Bis hierhin
